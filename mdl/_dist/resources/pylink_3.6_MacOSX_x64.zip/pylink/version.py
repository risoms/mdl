vernum=(1, 11, 0, 0)
